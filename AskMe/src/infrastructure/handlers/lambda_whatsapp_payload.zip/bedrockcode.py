import json
import os
import boto3

lambda_client = boto3.client('lambda')

PRIVATE_LAMBDA_NAME = os.environ.get('PRIVATE_LAMBDA_NAME')
MAX_CHARS = 800

# ==========================================
# AQUI ESTÁ A SENHA DO WEBHOOK!
# Essa é a senha que você vai colar lá no painel da Meta
# ==========================================
VERIFY_TOKEN = os.environ.get('VERIFY_TOKEN')

def lambda_handler(event, context):
    try:
        # Descobre se a Meta está mandando um GET (Aperto de mão) ou POST (Mensagem de cliente)
        http_method = event['requestContext']['http']['method']
        
        # ==========================================
        # 1. O APERTO DE MÃO (Validação do Webhook via GET)
        # ==========================================
        if http_method == 'GET':
            query_params = event.get('queryStringParameters', {})
            mode = query_params.get('hub.mode')
            token = query_params.get('hub.verify_token')
            challenge = query_params.get('hub.challenge')
            
            # Se o token que a Meta mandou bater com o nosso, a gente devolve o challenge
            if mode == 'subscribe' and token == VERIFY_TOKEN:
                print("Webhook verificado com sucesso pela Meta!")
                return {
                    'statusCode': 200,
                    'body': challenge
                }
            else:
                return {'statusCode': 403, 'body': 'Falha na verificação do Token'}

        # ==========================================
        # 2. RECEBENDO MENSAGENS (O POST do cliente)
        # ==========================================
        elif http_method == 'POST':
            body_str = event.get('body', '{}')
            parsed_body = json.loads(body_str)
            
            # Navegando no JSON maluco do WhatsApp para achar a mensagem e o telefone
            try:
                entry = parsed_body['entry'][0]
                changes = entry['changes'][0]
                value = changes['value']
                
                # Ignora mensagens de status de entrega/leitura do WhatsApp
                if 'messages' not in value:
                    return {'statusCode': 200, 'body': 'Evento ignorado'}
                    
                message_data = value['messages'][0]
                telefone_cliente = message_data['from']
                
                # Só aceita mensagens de texto (ignora áudio, imagem, figurinha por enquanto)
                if message_data['type'] == 'text':
                    mensagem_do_cliente = message_data['text']['body']
                else:
                    return {'statusCode': 200, 'body': 'Tipo de mensagem não suportado'}
                    
            except KeyError:
                return {'statusCode': 200, 'body': 'Payload não reconhecido'}

            # O Disjuntor: Validação rígida do tamanho do texto
            if len(mensagem_do_cliente) > MAX_CHARS:
                print(f"ALERTA SECURITY: Mensagem longa bloqueada. {len(mensagem_do_cliente)} chars")
                return {'statusCode': 200, 'body': 'Mensagem bloqueada por tamanho'}
            
            # Empacota a mensagem limpa e o telefone para a Lambda Privada
            payload_limpo = {
                'telefone': telefone_cliente,
                'mensagem': mensagem_do_cliente
            }
            
            # Invoca a Lambda Privada de forma ASSÍNCRONA ('Event')
            print("Enviando para a Lambda Privada processar com o Bedrock...")
            lambda_client.invoke(
                FunctionName=PRIVATE_LAMBDA_NAME,
                InvocationType='Event', 
                Payload=json.dumps(payload_limpo)
            )
            
            # Devolve 200 OK na mesma hora para a Meta não ficar impaciente
            return {'statusCode': 200, 'body': 'EVENT_RECEIVED'}
            
    except Exception as e:
        print(f"ERRO CRÍTICO: {str(e)}")
        return {'statusCode': 500, 'body': 'Erro interno'}